let currentAudio = null;

document.addEventListener("DOMContentLoaded", function () {
  document.getElementById("saveBtn").addEventListener("click", startSaveMode);
  document.getElementById("reinforceBtn").addEventListener("click", startReinforceMode);
  document.getElementById("testBtn").addEventListener("click", startTestMode);
});

function startSaveMode() {
  const section = document.getElementById("workflow");
  section.innerHTML = `
    <h3>حفظ - الخطوة 1: اختر السورة والآيات</h3>
    <label>اسم السورة: 
      <select id="surahName">
        <option value="1">الفاتحة</option>
        <option value="2">البقرة</option>
        <option value="3">آل عمران</option>
        <option value="4">النساء</option>
        <option value="5">المائدة</option>
        <option value="6">الأنعام</option>
        <option value="7">الأعراف</option>
        <option value="8">الأنفال</option>
        <option value="9">التوبة</option>
        <option value="10">يونس</option>
        <option value="11">هود</option>
        <option value="12">يوسف</option>
        <option value="13">الرعد</option>
        <option value="14">إبراهيم</option>
        <option value="15">الحجر</option>
        <option value="16">النحل</option>
        <option value="17">الإسراء</option>
        <option value="18">الكهف</option>
        <option value="19">مريم</option>
        <option value="20">طه</option>
        <option value="21">الأنبياء</option>
        <option value="22">الحج</option>
        <option value="23">المؤمنون</option>
        <option value="24">النور</option>
        <option value="25">الفرقان</option>
        <option value="26">الشعراء</option>
        <option value="27">النمل</option>
        <option value="28">القصص</option>
        <option value="29">العنكبوت</option>
        <option value="30">الروم</option>
        <option value="31">لقمان</option>
        <option value="32">السجدة</option>
        <option value="33">الأحزاب</option>
        <option value="34">سبأ</option>
        <option value="35">فاطر</option>
        <option value="36">يس</option>
        <option value="37">الصافات</option>
        <option value="38">ص</option>
        <option value="39">الزمر</option>
        <option value="40">غافر</option>
        <option value="41">فصلت</option>
        <option value="42">الشورى</option>
        <option value="43">الزخرف</option>
        <option value="44">الدخان</option>
        <option value="45">الجاثية</option>
        <option value="46">الأحقاف</option>
        <option value="47">محمد</option>
        <option value="48">الفتح</option>
        <option value="49">الحجرات</option>
        <option value="50">ق</option>
        <option value="51">الذاريات</option>
        <option value="52">الطور</option>
        <option value="53">النجم</option>
        <option value="54">القمر</option>
        <option value="55">الرحمن</option>
        <option value="56">الواقعة</option>
        <option value="57">الحديد</option>
        <option value="58">المجادلة</option>
        <option value="59">الحشر</option>
        <option value="60">الممتحنة</option>
        <option value="61">الصف</option>
        <option value="62">الجمعة</option>
        <option value="63">المنافقون</option>
        <option value="64">التغابن</option>
        <option value="65">الطلاق</option>
        <option value="66">التحريم</option>
        <option value="67">الملك</option>
        <option value="68">القلم</option>
        <option value="69">الحاقة</option>
        <option value="70">المعارج</option>
        <option value="71">نوح</option>
        <option value="72">الجن</option>
        <option value="73">المزمل</option>
        <option value="74">المدثر</option>
        <option value="75">القيامة</option>
        <option value="76">الإنسان</option>
        <option value="77">المرسلات</option>
        <option value="78">النبأ</option>
        <option value="79">النازعات</option>
        <option value="80">عبس</option>
        <option value="81">التكوير</option>
        <option value="82">الإنفطار</option>
        <option value="83">المطففين</option>
        <option value="84">الإنشقاق</option>
        <option value="85">البروج</option>
        <option value="86">الطارق</option>
        <option value="87">الأعلى</option>
        <option value="88">الغاشية</option>
        <option value="89">الفجر</option>
        <option value="90">البلد</option>
        <option value="91">الشمس</option>
        <option value="92">الليل</option>
        <option value="93">الضحى</option>
        <option value="94">الشرح</option>
        <option value="95">التين</option>
        <option value="96">العلق</option>
        <option value="97">القدر</option>
        <option value="98">البينة</option>
        <option value="99">الزلزلة</option>
        <option value="100">العاديات</option>
        <option value="101">القارعة</option>
        <option value="102">التكاثر</option>
        <option value="103">العصر</option>
        <option value="104">الهمزة</option>
        <option value="105">الفيل</option>
        <option value="106">قريش</option>
        <option value="107">الماعون</option>
        <option value="108">الكوثر</option>
        <option value="109">الكافرون</option>
        <option value="110">النصر</option>
        <option value="111">المسد</option>
        <option value="112">الإخلاص</option>
        <option value="113">الفلق</option>
        <option value="114">الناس</option>
      </select>
    </label><br>
    <label>من الآية: <input type="number" id="startAyah" min="1"></label><br>
    <label>إلى الآية: <input type="number" id="endAyah" min="1"></label><br><br>
    <button id="playBtn">تشغيل الآيات (5 مرات)</button>
    <div id="ayahDisplay"></div>
    <div id="audioControls"></div>
  `;

  document.getElementById("playBtn").addEventListener("click", playSelectedAyat);
}

async function playSelectedAyat() {
  const surah = document.getElementById("surahName").value;
  const start = parseInt(document.getElementById("startAyah").value);
  const end = parseInt(document.getElementById("endAyah").value);
  const ayahDisplay = document.getElementById("ayahDisplay");
  const audioControls = document.getElementById("audioControls");

  if (!surah || !start || !end || start > end) {
    alert("يرجى إدخال بيانات صحيحة.");
    return;
  }

  ayahDisplay.innerHTML = "<h4>نص الآيات:</h4>";
  audioControls.innerHTML = "";

  for (let i = start; i <= end; i++) {
    try {
      const response = await fetch(`https://api.alquran.cloud/v1/ayah/${surah}:${i}`);
      const data = await response.json();
      const ayahText = data.data.text;
      const ayahElement = document.createElement("p");
      ayahElement.textContent = `${i}. ${ayahText}`;
      ayahDisplay.appendChild(ayahElement);
    } catch (error) {
      console.error("Error fetching Ayah:", error);
    }
  }

  playAudio(surah, start, end, 5, () =>
    showReadAyatStep(surah, start, end, 5, "هل قرأت الآيات 5 مرات؟", () =>
      reciteAyahByAyah(surah, start, end)
    )
  );
}

function playAudio(surah, start, end, repeatCount, onComplete) {
  let currentRepeat = 0;

  function playCurrentRepeat() {
    if (currentRepeat >= repeatCount) {
      const controls = document.getElementById("audioControls");
      controls.innerHTML = `
        <p>تم التكرار ${repeatCount} مرات.</p>
        <button id="nextBtn">التالي</button>
      `;

      document.getElementById("nextBtn").addEventListener("click", onComplete);
      return;
    }

    let currentAyah = start;
    const audioControls = document.getElementById("audioControls");
    audioControls.innerHTML = `<p>التكرار رقم ${currentRepeat + 1}</p>`;

    function playNextAyah() {
      if (currentAyah > end) {
        currentRepeat++;
        playCurrentRepeat();
        return;
      }

      const ayahStr = String(currentAyah).padStart(3, '0');
      const surahStr = String(surah).padStart(3, '0');
      const url = `https://verses.quran.com/AbdulBaset/Murattal/mp3/${surahStr}${ayahStr}.mp3`;

      if (currentAudio) currentAudio.pause();
      currentAudio = new Audio(url);
      currentAudio.play();

      currentAudio.onended = () => {
        currentAyah++;
        playNextAyah();
      };

      currentAudio.onerror = () => {
        console.warn("خطأ في تحميل الصوت. يتجاوز الآية.");
        currentAyah++;
        playNextAyah();
      };
    }

    playNextAyah();
  }

  playCurrentRepeat();
}

function showReadAyatStep(surah, start, end, repeatCount, nextButtonText, onNext) {
  const workflow = document.getElementById("workflow");
  workflow.innerHTML = `
    <h3>الخطوة 2: اقرأ الآيات المختارة ${repeatCount} مرات بصوتك</h3>
    <div id="selectedAyatDisplay"></div>
    <button id="confirmReadBtn">${nextButtonText}</button>
  `;

  const selectedAyatDisplay = document.getElementById("selectedAyatDisplay");

  for (let i = start; i <= end; i++) {
    fetch(`https://api.alquran.cloud/v1/ayah/${surah}:${i}`)
      .then(res => res.json())
      .then(data => {
        const p = document.createElement("p");
        p.textContent = `${i}. ${data.data.text}`;
        selectedAyatDisplay.appendChild(p);
      })
      .catch(err => {
        console.error("خطأ في جلب الآيات:", err);
      });
  }

  document.getElementById("confirmReadBtn").addEventListener("click", onNext);
}

function reciteAyahByAyah(surah, start, end) {
  let currentAyah = start;
  const workflow = document.getElementById("workflow");
  workflow.innerHTML = `
    <h3>الخطوة 3: استمع إلى الآيات واحدة تلو الأخرى واقرأ بعد نهاية كل آية</h3>
    <div id="recitationStatus"></div>
  `;

  const recitationStatus = document.getElementById("recitationStatus");

  function playCurrentAyah() {
    if (currentAyah > end) {
      workflow.innerHTML = `<h3>اكتمل الحفظ [ان لم تحفظ اعد الكرة ثم ثبت حفظك]</h3>`;
      return;
    }

    // Fetch and display the current ayah text
    fetch(`https://api.alquran.cloud/v1/ayah/${surah}:${currentAyah}`)
      .then(res => res.json())
      .then(data => {
        const ayahText = data.data.text;

        recitationStatus.innerHTML = `
          <p>اقرأ الآية: ${currentAyah}</p>
          <p>${ayahText}</p>
        `;

        const ayahStr = String(currentAyah).padStart(3, '0');
        const surahStr = String(surah).padStart(3, '0');
        const url = `https://verses.quran.com/AbdulBaset/Murattal/mp3/${surahStr}${ayahStr}.mp3`;

        if (currentAudio) currentAudio.pause();
        currentAudio = new Audio(url);
        currentAudio.play();

        currentAudio.onended = () => {
          recitationStatus.innerHTML = `
            <p>هل قرأت الآية؟</p>
            <button id="nextAyahBtn">نعم، التالي</button>
          `;
          document.getElementById("nextAyahBtn").addEventListener("click", () => {
            currentAyah++;
            playCurrentAyah();
          });
        };

        currentAudio.onerror = () => {
          console.warn("خطأ في تحميل الصوت. يتجاوز الآية.");
          currentAyah++;
          playCurrentAyah();
        };
      })
      .catch(err => {
        console.error("خطأ في جلب الآية:", err);
        currentAyah++;
        playCurrentAyah();
      });
  }

  playCurrentAyah();
}

function startReinforceMode() {
  const section = document.getElementById("workflow");
  section.innerHTML = `
    <h3>تثبيت الحفظ - الخطوة 1: اختر السورة والآيات</h3>
    <label>اسم السورة: 
      <select id="surahName">
        <option value="1">الفاتحة</option>
        <option value="2">البقرة</option>
        <option value="3">آل عمران</option>
        <option value="4">النساء</option>
        <option value="5">المائدة</option>
        <option value="6">الأنعام</option>
        <option value="7">الأعراف</option>
        <option value="8">الأنفال</option>
        <option value="9">التوبة</option>
        <option value="10">يونس</option>
        <option value="11">هود</option>
        <option value="12">يوسف</option>
        <option value="13">الرعد</option>
        <option value="14">إبراهيم</option>
        <option value="15">الحجر</option>
        <option value="16">النحل</option>
        <option value="17">الإسراء</option>
        <option value="18">الكهف</option>
        <option value="19">مريم</option>
        <option value="20">طه</option>
        <option value="21">الأنبياء</option>
        <option value="22">الحج</option>
        <option value="23">المؤمنون</option>
        <option value="24">النور</option>
        <option value="25">الفرقان</option>
        <option value="26">الشعراء</option>
        <option value="27">النمل</option>
        <option value="28">القصص</option>
        <option value="29">العنكبوت</option>
        <option value="30">الروم</option>
        <option value="31">لقمان</option>
        <option value="32">السجدة</option>
        <option value="33">الأحزاب</option>
        <option value="34">سبأ</option>
        <option value="35">فاطر</option>
        <option value="36">يس</option>
        <option value="37">الصافات</option>
        <option value="38">ص</option>
        <option value="39">الزمر</option>
        <option value="40">غافر</option>
        <option value="41">فصلت</option>
        <option value="42">الشورى</option>
        <option value="43">الزخرف</option>
        <option value="44">الدخان</option>
        <option value="45">الجاثية</option>
        <option value="46">الأحقاف</option>
        <option value="47">محمد</option>
        <option value="48">الفتح</option>
        <option value="49">الحجرات</option>
        <option value="50">ق</option>
        <option value="51">الذاريات</option>
        <option value="52">الطور</option>
        <option value="53">النجم</option>
        <option value="54">القمر</option>
        <option value="55">الرحمن</option>
        <option value="56">الواقعة</option>
        <option value="57">الحديد</option>
        <option value="58">المجادلة</option>
        <option value="59">الحشر</option>
        <option value="60">الممتحنة</option>
        <option value="61">الصف</option>
        <option value="62">الجمعة</option>
        <option value="63">المنافقون</option>
        <option value="64">التغابن</option>
        <option value="65">الطلاق</option>
        <option value="66">التحريم</option>
        <option value="67">الملك</option>
        <option value="68">القلم</option>
        <option value="69">الحاقة</option>
        <option value="70">المعارج</option>
        <option value="71">نوح</option>
        <option value="72">الجن</option>
        <option value="73">المزمل</option>
        <option value="74">المدثر</option>
        <option value="75">القيامة</option>
        <option value="76">الإنسان</option>
        <option value="77">المرسلات</option>
        <option value="78">النبأ</option>
        <option value="79">النازعات</option>
        <option value="80">عبس</option>
        <option value="81">التكوير</option>
        <option value="82">الإنفطار</option>
        <option value="83">المطففين</option>
        <option value="84">الإنشقاق</option>
        <option value="85">البروج</option>
        <option value="86">الطارق</option>
        <option value="87">الأعلى</option>
        <option value="88">الغاشية</option>
        <option value="89">الفجر</option>
        <option value="90">البلد</option>
        <option value="91">الشمس</option>
        <option value="92">الليل</option>
        <option value="93">الضحى</option>
        <option value="94">الشرح</option>
        <option value="95">التين</option>
        <option value="96">العلق</option>
        <option value="97">القدر</option>
        <option value="98">البينة</option>
        <option value="99">الزلزلة</option>
        <option value="100">العاديات</option>
        <option value="101">القارعة</option>
        <option value="102">التكاثر</option>
        <option value="103">العصر</option>
        <option value="104">الهمزة</option>
        <option value="105">الفيل</option>
        <option value="106">قريش</option>
        <option value="107">الماعون</option>
        <option value="108">الكوثر</option>
        <option value="109">الكافرون</option>
        <option value="110">النصر</option>
        <option value="111">المسد</option>
        <option value="112">الإخلاص</option>
        <option value="113">الفلق</option>
        <option value="114">الناس</option>
      </select>
    </label><br>
    <label>من الآية: <input type="number" id="startAyah" min="1"></label><br>
    <label>إلى الآية: <input type="number" id="endAyah" min="1"></label><br><br>
    <button id="playBtn">تشغيل الآيات (10 مرات)</button>
    <div id="ayahDisplay"></div>
    <div id="audioControls"></div>
  `;

  document.getElementById("playBtn").addEventListener("click", function () {
    const surah = document.getElementById("surahName").value;
    const start = parseInt(document.getElementById("startAyah").value);
    const end = parseInt(document.getElementById("endAyah").value);

    if (!surah || !start || !end || start > end) {
      alert("يرجى إدخال بيانات صحيحة.");
      return;
    }

    const ayahDisplay = document.getElementById("ayahDisplay");
    ayahDisplay.innerHTML = "<h4>نص الآيات:</h4>";

    for (let i = start; i <= end; i++) {
      fetch(`https://api.alquran.cloud/v1/ayah/${surah}:${i}`)
        .then(res => res.json())
        .then(data => {
          const ayahText = data.data.text;
          const ayahElement = document.createElement("p");
          ayahElement.textContent = `${i}. ${ayahText}`;
          ayahDisplay.appendChild(ayahElement);
        })
        .catch(err => {
          console.error("Error fetching Ayah:", err);
        });
    }

    playAudio(surah, start, end, 10, () =>
      showReadAyatStep(surah, start, end, 10, "هل قرأت الآيات 10 مرات؟", () =>
        reciteAyahByAyah(surah, start, end)
      )
    );
  });
}

function startTestMode() {
  const section = document.getElementById("workflow");
  section.innerHTML = `<h3>اختبار الحفظ — تحت التطوير</h3>`;
}


